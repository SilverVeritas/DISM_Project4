/* MainActivity.java */
/***
 * Author: Pat Serrano (pserrano)
 * Last Modified: Nov 21, 2024
 *
 * The main activity of the Android application. Serves as the primary entry point
 * and manages the core user interface for anime search functionality.
 *
 * Features:
 * - Search bar for anime queries
 * - RecyclerView for displaying search results
 * - Navigation to anime details
 * - Error handling and network state management
 * - Integration with AnimeGridFragment for featured content
 *
 * Uses Volley for network requests and implements search functionality
 * with real-time updates and error feedback.
 */
package ds.Task2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import android.content.Context;

public class MainActivity extends AppCompatActivity implements AnimeAdapter.OnAnimeClickListener {
    private static final String TAG = "MainActivity";

    private static final String SERVLET_API = "https://didactic-engine-vjjv6764xxfx6v7-8080.app.github.dev/anime";

    private EditText searchInput;
    private Button searchButton;
    private Button cancelButton;
    private TextView resultsText;
    private RecyclerView animeList;
    private AnimeAdapter animeAdapter;
    private RequestQueue requestQueue;
    private View fragmentContainer;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Volley RequestQueue
        requestQueue = Volley.newRequestQueue(this);

        // Initialize views
        searchInput = findViewById(R.id.searchInput);
        searchButton = findViewById(R.id.searchButton);
        cancelButton = findViewById(R.id.cancelButton);
        resultsText = findViewById(R.id.resultsText);
        animeList = findViewById(R.id.animeList);
        fragmentContainer = findViewById(R.id.fragment_container);

        if (savedInstanceState == null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.add(R.id.fragment_container, new AnimeGridFragment());
            transaction.commit();
        }

        // Initially hide cancel button
        cancelButton.setVisibility(View.GONE);

        // Setup RecyclerView
        animeList.setLayoutManager(new LinearLayoutManager(this));
        animeAdapter = new AnimeAdapter(new ArrayList<>(), this);
        animeList.setAdapter(animeAdapter);

        // Setup text change listener to show/hide cancel button
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                cancelButton.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Setup search button click listener with debug feedback
        searchButton.setOnClickListener(v -> {
            Log.d(TAG, "Search button clicked");
            Toast.makeText(this, "Searching...", Toast.LENGTH_SHORT).show();
            hideKeyboard();
            performSearch();
        });

        // Setup cancel button click listener
        cancelButton.setOnClickListener(v -> {
            Log.d(TAG, "Cancel button clicked");
            hideKeyboard();
            resetSearch();
        });

        // Setup touch listener for parent layout to hide keyboard when touching outside
        findViewById(android.R.id.content).setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                View currentFocus = getCurrentFocus();
                if (currentFocus instanceof EditText) {
                    float x = event.getX();
                    float y = event.getY();
                    int[] location = new int[2];
                    currentFocus.getLocationOnScreen(location);
                    if (y < location[1] || y > location[1] + currentFocus.getHeight() ||
                            x < location[0] || x > location[0] + currentFocus.getWidth()) {
                        hideKeyboard();
                        currentFocus.clearFocus();
                    }
                }
            }
            return false;
        });
    }

    private void hideKeyboard() {
        View view = getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
            view.clearFocus();
        }
    }

    private void resetSearch() {
        Log.d(TAG, "Resetting search");
        searchInput.setText("");
        animeAdapter.updateData(new ArrayList<>());
        animeList.setVisibility(View.GONE);
        resultsText.setVisibility(View.GONE);
        fragmentContainer.setVisibility(View.VISIBLE);
        searchInput.clearFocus();
        cancelButton.setVisibility(View.GONE);
    }

    private void performSearch() {
        String query = searchInput.getText().toString().trim();
        Log.d(TAG, "Performing search for query: " + query);

        if (query.isEmpty()) {
            resultsText.setVisibility(View.VISIBLE);
            resultsText.setText("Please enter a search term");
            return;
        }

        // Show loading state
        resultsText.setVisibility(View.VISIBLE);
        resultsText.setText("Searching...");
        animeList.setVisibility(View.GONE);
        fragmentContainer.setVisibility(View.GONE);

        try {
            // Encode the query
            String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8.toString());
            // Update the URL to point to your servlet's search endpoint
            String url = SERVLET_API + "/search?q=" + encodedQuery;
            Log.d(TAG, "Making request to URL: " + url);

            JsonObjectRequest request = new JsonObjectRequest(
                    Request.Method.GET,
                    url,
                    null,
                    response -> {
                        Log.d(TAG, "Received API response");
                        try {
                            JSONObject pagination = response.getJSONObject("pagination");
                            JSONObject items = pagination.getJSONObject("items");
                            int totalResults = items.getInt("count");
                            Log.d(TAG, "Total results: " + totalResults);

                            if (totalResults == 0) {
                                resultsText.setText("No results found");
                                animeList.setVisibility(View.GONE);
                                return;
                            }

                            // Parse results
                            JSONArray data = response.getJSONArray("data");
                            List<AnimeItem> animeItems = new ArrayList<>();

                            for (int i = 0; i < data.length(); i++) {
                                JSONObject anime = data.getJSONObject(i);
                                String rating = anime.optString("rating", "").toLowerCase();

                                // DEBUG: Log rating values
                                Log.d(TAG, "Anime ID: " + anime.getInt("mal_id") + ", Rating: " + rating);

                                // Include content up to R17+, adjust conditions based on actual rating values
                                if (rating.contains("g") || rating.contains("pg") ||
                                        rating.contains("pg-13") || rating.contains("r") ||
                                        rating.isEmpty()) { // Include items with no rating

                                    // Populate AnimeItem and add to the list
                                    AnimeItem item = new AnimeItem();
                                    item.id = anime.getInt("mal_id");
                                    item.title = anime.getString("title");
                                    item.type = anime.optString("type", "Unknown");
                                    item.episodes = anime.optInt("episodes", 0);
                                    item.score = anime.optDouble("score", 0.0);
                                    item.status = anime.optString("status", "Unknown");
                                    item.synopsis = anime.optString("synopsis", "No synopsis available");

                                    JSONObject images = anime.getJSONObject("images");
                                    JSONObject jpg = images.getJSONObject("jpg");
                                    item.imageUrl = jpg.getString("image_url");

                                    animeItems.add(item);
                                }
                            }


                            // Update UI
                            if (animeItems.isEmpty()) {
                                resultsText.setVisibility(View.VISIBLE);
                                resultsText.setText("No results found");
                                animeList.setVisibility(View.GONE);
                            } else {
                                resultsText.setVisibility(View.GONE);
                                animeList.setVisibility(View.VISIBLE);
                                animeAdapter.updateData(animeItems);
                            }
                            Log.d(TAG, "Updated UI with " + animeItems.size() + " items");

                        } catch (JSONException e) {
                            Log.e(TAG, "Error parsing response: " + e.getMessage());
                            resultsText.setText("Error parsing results");
                            e.printStackTrace();
                        }
                    },
                    error -> {
                        Log.e(TAG, "API Error: " + error.getMessage());
                        String errorMessage = "Error: ";
                        if (error.networkResponse != null) {
                            errorMessage += "Status Code: " + error.networkResponse.statusCode;
                        } else {
                            errorMessage += error.getMessage();
                        }
                        resultsText.setText(errorMessage);
                        animeList.setVisibility(View.GONE);
                    }
            );

            requestQueue.add(request);
            Log.d(TAG, "Request added to queue");

        } catch (UnsupportedEncodingException e) {
            Log.e(TAG, "Error encoding query: " + e.getMessage());
            resultsText.setText("Error processing search query");
            e.printStackTrace();
        }
    }

    @Override
    public void onAnimeClick(AnimeItem anime) {
        Intent intent = new Intent(this, AnimeDetailActivity.class);
        intent.putExtra("id", anime.id);
        intent.putExtra("title", anime.title);
        intent.putExtra("imageUrl", anime.imageUrl);
        intent.putExtra("type", anime.type);
        intent.putExtra("episodes", anime.episodes);
        intent.putExtra("score", anime.score);
        intent.putExtra("status", anime.status);
        intent.putExtra("synopsis", anime.synopsis);
        startActivity(intent);
    }
}
