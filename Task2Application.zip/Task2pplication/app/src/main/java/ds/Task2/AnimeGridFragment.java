package ds.Task2;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.tabs.TabLayout;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import android.util.Log;

public class AnimeGridFragment extends Fragment implements AnimeGridAdapter.OnAnimeClickListener {
    private static final String TAG = "AnimeGridFragment";
    // Update the base URL to point to your servlet
    private static final String SERVLET_API = "https://didactic-engine-vjjv6764xxfx6v7-8080.app.github.dev/anime";

    private TabLayout tabLayout;
    private RecyclerView animeGrid;
    private TextView loadingText;
    private AnimeGridAdapter gridAdapter;
    private RequestQueue requestQueue;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_anime_grid, container, false);

        // Initialize Volley RequestQueue
        requestQueue = Volley.newRequestQueue(requireContext());

        // Initialize views
        tabLayout = view.findViewById(R.id.tabLayout);
        animeGrid = view.findViewById(R.id.animeGrid);
        loadingText = view.findViewById(R.id.loadingText);

        // Setup RecyclerView with Grid Layout
        GridLayoutManager layoutManager = new GridLayoutManager(getContext(), 2);
        animeGrid.setLayoutManager(layoutManager);
        gridAdapter = new AnimeGridAdapter(new ArrayList<>(), this);
        animeGrid.setAdapter(gridAdapter);

        // Setup tabs
        setupTabs();

        // Load initial data (Top Anime)
        loadTopAnime();

        return view;
    }

    private void setupTabs() {
        tabLayout.addTab(tabLayout.newTab().setText("Top All Time"));
        tabLayout.addTab(tabLayout.newTab().setText("Top Airing"));
        tabLayout.addTab(tabLayout.newTab().setText("Seasonal"));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case 0:
                        loadTopAnime(); // All time
                        break;
                    case 1:
                        loadTopAiringAnime(); // Currently airing
                        break;
                    case 2:
                        loadSeasonalAnime(); // Seasonal
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void loadTopAiringAnime() {
        showLoading();
        String url = SERVLET_API + "/top-airing";
        Log.d(TAG, "Loading top airing anime with URL: " + url);
        makeAnimeRequest(url);
    }

    private void loadTopAnime() {
        showLoading();
        String url = SERVLET_API + "/top";
        Log.d(TAG, "Loading top anime with URL: " + url);
        makeAnimeRequest(url);
    }

    private void loadSeasonalAnime() {
        showLoading();
        String url = SERVLET_API + "/seasonal";
        Log.d(TAG, "Loading seasonal anime with URL: " + url);
        makeAnimeRequest(url);
    }

    private void showLoading() {
        loadingText.setVisibility(View.VISIBLE);
        loadingText.setText("Loading...");
        animeGrid.setVisibility(View.GONE);
    }

    private void makeAnimeRequest(String url) {
        Log.d(TAG, "Making request to URL: " + url);
        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                response -> {
                    Log.d(TAG, "Received response successfully");
                    parseAnimeResponse(response);
                },
                error -> {
                    Log.e(TAG, "Error fetching anime data: " + error.toString());
                    if (error.networkResponse != null) {
                        Log.e(TAG, "Status Code: " + error.networkResponse.statusCode);
                    }
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(() -> {
                            loadingText.setText("Error: " + error.getMessage());
                            animeGrid.setVisibility(View.GONE);
                        });
                    }
                }
        );

        requestQueue.add(request);
    }

    private void parseAnimeResponse(JSONObject response) {
        try {
            JSONArray data = response.getJSONArray("data");
            Log.d(TAG, "Got data array with length: " + data.length());

            List<AnimeItem> animeItems = new ArrayList<>();
            Set<Integer> uniqueIds = new HashSet<>();

            for (int i = 0; i < data.length(); i++) {
                JSONObject anime = data.getJSONObject(i);
                int malId = anime.getInt("mal_id");
                String title = anime.getString("title");
                Log.d(TAG, "Processing anime: " + title + " (ID: " + malId + ")");

                if (!uniqueIds.contains(malId)) {
                    uniqueIds.add(malId);
                    AnimeItem item = new AnimeItem();
                    item.id = malId;
                    item.title = title;
                    item.type = anime.optString("type", "Unknown");
                    item.episodes = anime.optInt("episodes", 0);
                    item.score = anime.optDouble("score", 0.0);
                    item.status = anime.optString("status", "Unknown");
                    item.synopsis = anime.optString("synopsis", "No synopsis available");

                    JSONObject images = anime.getJSONObject("images");
                    JSONObject jpg = images.getJSONObject("jpg");
                    item.imageUrl = jpg.getString("image_url");

                    animeItems.add(item);
                    Log.d(TAG, "Added anime to list: " + title);
                }
            }

            Log.d(TAG, "Final list size: " + animeItems.size());

            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> {
                    if (animeItems.isEmpty()) {
                        Log.d(TAG, "No items to display");
                        loadingText.setVisibility(View.VISIBLE);
                        loadingText.setText("No results found");
                        animeGrid.setVisibility(View.GONE);
                    } else {
                        Log.d(TAG, "Displaying " + animeItems.size() + " items");
                        loadingText.setVisibility(View.GONE);
                        animeGrid.setVisibility(View.VISIBLE);
                        gridAdapter.updateData(animeItems);
                    }
                });
            }

        } catch (JSONException e) {
            Log.e(TAG, "Error parsing response: " + e.getMessage());
            Log.e(TAG, "Full response: " + response.toString());
            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> {
                    loadingText.setText("Error parsing results");
                    animeGrid.setVisibility(View.GONE);
                });
            }
        }
    }

    @Override
    public void onAnimeClick(AnimeItem anime) {
        Intent intent = new Intent(getContext(), AnimeDetailActivity.class);
        intent.putExtra("id", anime.id);
        intent.putExtra("title", anime.title);
        intent.putExtra("imageUrl", anime.imageUrl);
        intent.putExtra("type", anime.type);
        intent.putExtra("episodes", anime.episodes);
        intent.putExtra("score", anime.score);
        intent.putExtra("status", anime.status);
        intent.putExtra("synopsis", anime.synopsis);
        startActivity(intent);
    }
}
