/* AnimeAdapter.java */
/***
 * Author: Pat Serrano (pserrano)
 * Last Modified: Nov 21, 2024
 *
 * RecyclerView adapter for displaying anime items in a list layout.
 * Used in the main search results view to show detailed anime entries
 * with more information than the grid view.
 *
 * Features:
 * - Detailed anime information display
 * - Efficient view recycling
 * - Image loading with Glide
 * - Click handling for navigation to details
 */

package ds.Task2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

public class AnimeAdapter extends RecyclerView.Adapter<AnimeAdapter.AnimeViewHolder> {
    private List<AnimeItem> animeList;
    private final OnAnimeClickListener listener;

    public interface OnAnimeClickListener {
        void onAnimeClick(AnimeItem anime);
    }

    public AnimeAdapter(List<AnimeItem> animeList, OnAnimeClickListener listener) {
        this.animeList = animeList;
        this.listener = listener;
    }

    public void updateData(List<AnimeItem> newData) {
        this.animeList = newData;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public AnimeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_anime, parent, false);
        return new AnimeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AnimeViewHolder holder, int position) {
        AnimeItem anime = animeList.get(position);

        holder.titleView.setText(anime.title);
        holder.typeView.setText("Type: " + anime.type);
        holder.episodesView.setText("Episodes: " + (anime.episodes == 0 ? "N/A" : anime.episodes));
        holder.scoreView.setText("Score: " + (anime.score == 0 ? "N/A" : String.format("%.2f", anime.score)));

        Glide.with(holder.itemView.getContext())
                .load(anime.imageUrl)
                .centerCrop()
                .into(holder.imageView);

        holder.itemView.setOnClickListener(v -> listener.onAnimeClick(anime));
    }

    @Override
    public int getItemCount() {
        return animeList.size();
    }

    static class AnimeViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView titleView;
        TextView typeView;
        TextView episodesView;
        TextView scoreView;

        AnimeViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.animeImage);
            titleView = itemView.findViewById(R.id.animeTitle);
            typeView = itemView.findViewById(R.id.animeType);
            episodesView = itemView.findViewById(R.id.animeEpisodes);
            scoreView = itemView.findViewById(R.id.animeScore);
        }
    }
}