/* AnimeGridAdapter.java */
/***
 * Author: Pat Serrano (pserrano)
 * Last Modified: Nov 21, 2024
 *
 * RecyclerView adapter for displaying anime items in a grid layout.
 * Handles the creation and binding of grid item views, manages data updates,
 * and implements click listeners for navigation.
 *
 * Features:
 * - Efficient view recycling
 * - Image loading with Glide
 * - Click handling for item selection
 * - Dynamic data updates
 */

package ds.Task2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

public class AnimeGridAdapter extends RecyclerView.Adapter<AnimeGridAdapter.AnimeGridViewHolder> {
    private List<AnimeItem> animeList;
    private final OnAnimeClickListener listener;

    public interface OnAnimeClickListener {
        void onAnimeClick(AnimeItem anime);
    }

    public AnimeGridAdapter(List<AnimeItem> animeList, OnAnimeClickListener listener) {
        this.animeList = animeList;
        this.listener = listener;
    }

    public void updateData(List<AnimeItem> newData) {
        this.animeList = newData;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public AnimeGridViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_anime_grid, parent, false);
        return new AnimeGridViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AnimeGridViewHolder holder, int position) {
        AnimeItem anime = animeList.get(position);

        holder.titleView.setText(anime.title);
        holder.scoreView.setText("Score: " + (anime.score == 0 ? "N/A" : String.format("%.2f", anime.score)));

        Glide.with(holder.itemView.getContext())
                .load(anime.imageUrl)
                .centerCrop()
                .into(holder.imageView);

        holder.itemView.setOnClickListener(v -> listener.onAnimeClick(anime));
    }

    @Override
    public int getItemCount() {
        return animeList.size();
    }

    static class AnimeGridViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView titleView;
        TextView scoreView;

        AnimeGridViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.animeImage);
            titleView = itemView.findViewById(R.id.animeTitle);
            scoreView = itemView.findViewById(R.id.animeScore);
        }
    }
}