/* AnimeDetailActivity.java */
/***
 * Author: Pat Serrano (pserrano)
 * Last Modified: Nov 21, 2024
 *
 * Activity for displaying detailed information about a specific anime.
 * Receives anime data through intent extras and presents it in a
 * scrollable layout with rich media content.
 *
 * Features:
 * - Displays anime cover image using Glide
 * - Shows comprehensive anime information
 * - Provides navigation back to search results
 * - Implements responsive layout for different screen sizes
 */

package ds.Task2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;

public class AnimeDetailActivity extends AppCompatActivity {
    private ImageView detailAnimeImage;
    private TextView detailAnimeTitle;
    private TextView detailAnimeType;
    private TextView detailAnimeEpisodes;
    private TextView detailAnimeScore;
    private TextView detailAnimeStatus;
    private TextView detailAnimeSynopsis;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anime_detail);

        // Initialize views
        backButton = findViewById(R.id.backButton);
        detailAnimeImage = findViewById(R.id.detailAnimeImage);
        detailAnimeTitle = findViewById(R.id.detailAnimeTitle);
        detailAnimeType = findViewById(R.id.detailAnimeType);
        detailAnimeEpisodes = findViewById(R.id.detailAnimeEpisodes);
        detailAnimeScore = findViewById(R.id.detailAnimeScore);
        detailAnimeStatus = findViewById(R.id.detailAnimeStatus);
        detailAnimeSynopsis = findViewById(R.id.detailAnimeSynopsis);

        // Set back button click listener
        backButton.setOnClickListener(v -> finish());

        // Get data from intent
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String title = extras.getString("title", "");
            detailAnimeTitle.setText(title);

            String imageUrl = extras.getString("imageUrl", "");
            Glide.with(this)
                    .load(imageUrl)
                    .centerCrop()
                    .into(detailAnimeImage);

            detailAnimeType.setText("Type: " + extras.getString("type", "Unknown"));
            detailAnimeEpisodes.setText("Episodes: " + extras.getInt("episodes", 0));
            detailAnimeScore.setText("Score: " + String.format("%.2f", extras.getDouble("score", 0.0)));
            detailAnimeStatus.setText("Status: " + extras.getString("status", "Unknown"));
            detailAnimeSynopsis.setText(extras.getString("synopsis", "No synopsis available."));
        }
    }
}