/* AnimeItem.java */
/***
 * Author: Pat Serrano (pserrano)
 * Last Modified: Nov 21, 2024
 *
 * A data model class representing core anime information.
 * Used to standardize anime data transfer between different components
 * of the application. Captures essential anime metadata from the Jikan API.
 *
 * Properties:
 * - id: Unique identifier from MyAnimeList
 * - title: Anime title
 * - imageUrl: URL to anime cover image
 * - type: Type of anime (TV, Movie, OVA, etc.)
 * - episodes: Number of episodes
 * - score: Average user rating
 * - status: Airing status
 * - synopsis: Brief description of the anime
 */
package ds.Task2;

public class AnimeItem {
    public int id;
    public String title;
    public String imageUrl;
    public String type;
    public int episodes;
    public double score;
    public String status;
    public String synopsis;
}