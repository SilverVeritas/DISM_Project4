package ds.task2server;

import com.mongodb.client.*;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Accumulators;
import org.bson.Document;
import org.json.JSONObject;
import org.json.JSONException;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;

import static com.mongodb.client.model.Filters.gte;
import static com.mongodb.client.model.Sorts.descending;

/**
 * Author: Pat Serrano (pserrano)
 * Last Modified: Nov 22, 2024
 *
 * The AnimeModel class handles data access and business logic for the Anime Search application.
 * It interacts with the Jikan API and MongoDB to perform operations such as searching anime,
 * fetching details, and collecting analytics data for the dashboard.
 */
public class AnimeModel {
    private static final String JIKAN_API_BASE = "https://api.jikan.moe/v4";
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> logsCollection;
    private HttpClient httpClient;

    public AnimeModel(String connectionString) {
        mongoClient = MongoClients.create(connectionString);
        database = mongoClient.getDatabase("project4db");
        logsCollection = database.getCollection("anime_logs");

        httpClient = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .connectTimeout(Duration.ofSeconds(10))
                .build();
    }

    public String searchAnime(String query, String clientIP, String userAgent) throws Exception {
        long startTime = System.currentTimeMillis();

        String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8);
        String url = JIKAN_API_BASE + "/anime?q=" + encodedQuery;

        String responseBody = sendApiRequest(url);

        long endTime = System.currentTimeMillis();
        long responseTime = endTime - startTime;

        int resultCount = 0;
        try {
            JSONObject jsonResponse = new JSONObject(responseBody);
            JSONObject pagination = jsonResponse.getJSONObject("pagination");
            JSONObject items = pagination.getJSONObject("items");
            resultCount = items.getInt("count");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Log the search
        Document logEntry = new Document()
                .append("searchTerm", query)
                .append("responseTime", responseTime)
                .append("timestamp", new Date())
                .append("clientIP", clientIP)
                .append("userAgent", userAgent)
                .append("resultCount", resultCount);
        logsCollection.insertOne(logEntry);

        return responseBody;
    }

    public String getAnimeDetails(String animeId) throws Exception {
        String url = JIKAN_API_BASE + "/anime/" + animeId;
        return sendApiRequest(url);
    }

    public String getTopAnime() throws Exception {
        String url = JIKAN_API_BASE + "/top/anime?rating=g&rating=pg&rating=pg13&rating=r17";
        return sendApiRequest(url);
    }

    public String getTopAiringAnime() throws Exception {
        String url = JIKAN_API_BASE + "/top/anime?filter=airing&rating=pg13&rating=r17";
        return sendApiRequest(url);
    }

    public String getSeasonalAnime() throws Exception {
        String url = JIKAN_API_BASE + "/seasons/now?rating=g&rating=pg&rating=pg13&rating=r17";
        return sendApiRequest(url);
    }

    public Map<String, Object> getDashboardData() {
        Map<String, Object> dashboardData = new HashMap<>();

        // Top Searches
        List<Document> topSearches = logsCollection.aggregate(Arrays.asList(
                Aggregates.group("$searchTerm", Accumulators.sum("count", 1)),
                Aggregates.sort(descending("count")),
                Aggregates.limit(5)
        )).into(new ArrayList<>());

        // Average Response Time
        Document avgResponse = logsCollection.aggregate(Arrays.asList(
                Aggregates.group(null, Accumulators.avg("avgTime", "$responseTime"))
        )).first();

        // Today's Request Count
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        long todayCount = logsCollection.countDocuments(
                gte("timestamp", cal.getTime())
        );

        // Recent Logs
        List<Document> recentLogs = logsCollection.find()
                .sort(descending("timestamp"))
                .limit(10)
                .into(new ArrayList<>());

        dashboardData.put("topSearches", topSearches);
        dashboardData.put("avgResponseTime", avgResponse != null ? avgResponse.getDouble("avgTime") : 0.0);
        dashboardData.put("todayRequests", todayCount);
        dashboardData.put("recentLogs", recentLogs);

        return dashboardData;
    }

    private String sendApiRequest(String url) throws Exception {
        HttpRequest apiRequest = HttpRequest.newBuilder()
                .GET()
                .uri(URI.create(url))
                .header("Accept", "application/json")
                .build();

        HttpResponse<String> apiResponse = httpClient.send(apiRequest, HttpResponse.BodyHandlers.ofString());
        return apiResponse.body();
    }

    public void close() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
}
