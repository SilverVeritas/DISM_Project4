//package ds.task2server;
//
//import com.mongodb.client.*;
//import com.mongodb.client.model.Aggregates;
//import com.mongodb.client.model.Accumulators;
//import org.bson.Document;
//import org.json.JSONObject;
//import org.json.JSONException;
//
//import jakarta.servlet.ServletException;
//import jakarta.servlet.annotation.WebServlet;
//import jakarta.servlet.http.HttpServlet;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//
//import java.io.IOException;
//import java.net.URI;
//import java.net.URLEncoder;
//import java.net.http.HttpClient;
//import java.net.http.HttpRequest;
//import java.net.http.HttpResponse;
//import java.nio.charset.StandardCharsets;
//import java.time.Duration;
//import java.util.*;
//import static com.mongodb.client.model.Filters.*;
//import static com.mongodb.client.model.Sorts.*;
//
//@WebServlet("/anime/*")
//public class AnimeWebService extends HttpServlet {
//    private static final String JIKAN_API_BASE = "https://api.jikan.moe/v4";
//    private MongoClient mongoClient;
//    private MongoDatabase database;
//    private MongoCollection<Document> logsCollection;
//    private HttpClient httpClient;
//
//    @Override
//    public void init() throws ServletException {
//        // Replace <PASSWORD> with your actual MongoDB password
//        String connectionString = "mongodb+srv://pserrano:Dismproj1234@dism.zanxk.mongodb.net/?retryWrites=true&w=majority&appName=DISM";
//        try {
//            mongoClient = MongoClients.create(connectionString);
//            database = mongoClient.getDatabase("project4db");
//            logsCollection = database.getCollection("anime_logs");
//
//            httpClient = HttpClient.newBuilder()
//                    .version(HttpClient.Version.HTTP_2)
//                    .connectTimeout(Duration.ofSeconds(10))
//                    .build();
//        } catch (Exception e) {
//            throw new ServletException("Failed to initialize service", e);
//        }
//    }
//
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//
//        String pathInfo = request.getPathInfo();
//        if (pathInfo == null) pathInfo = "/";
//
//        try {
//            switch (pathInfo) {
//                case "/search":
//                    handleSearch(request, response);
//                    break;
//                case "/details":
//                    handleDetails(request, response);
//                    break;
//                case "/dashboard":
//                    handleDashboard(request, response);
//                    break;
//                case "/top":
//                    handleTopAnime(request, response);
//                    break;
//                case "/top-airing":
//                    handleTopAiring(request, response);
//                    break;
//                case "/seasonal":
//                    handleSeasonalAnime(request, response);
//                    break;
//                default:
//                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
//                    break;
//            }
//        } catch (Exception e) {
//            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
//                    "Error processing request: " + e.getMessage());
//        }
//    }
//
//    private void handleSearch(HttpServletRequest request, HttpServletResponse response)
//            throws IOException, InterruptedException {
//        String query = request.getParameter("q");
//        if (query == null || query.trim().isEmpty()) {
//            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Query parameter 'q' is required");
//            return;
//        }
//
//        long startTime = System.currentTimeMillis(); // Start time for response time calculation
//
//        String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8);
//        String url = JIKAN_API_BASE + "/anime?q=" + encodedQuery;
//
//        // Send the API request and get the response body
//        String responseBody = sendApiRequest(url);
//
//        long endTime = System.currentTimeMillis(); // End time for response time calculation
//        long responseTime = endTime - startTime;
//
//        // Get client IP and user agent
//        String clientIP = request.getRemoteAddr();
//        String userAgent = request.getHeader("User-Agent");
//
//        // Parse the response body to get resultCount
//        int resultCount = 0;
//        try {
//            JSONObject jsonResponse = new JSONObject(responseBody);
//            JSONObject pagination = jsonResponse.getJSONObject("pagination");
//            JSONObject items = pagination.getJSONObject("items");
//            resultCount = items.getInt("count");
//        } catch (JSONException e) {
//            // Handle parsing error if necessary
//            e.printStackTrace();
//        }
//
//        // Log the search term and response time into the database
//        Document logEntry = new Document()
//                .append("searchTerm", query)
//                .append("responseTime", responseTime)
//                .append("timestamp", new Date())
//                .append("clientIP", clientIP)
//                .append("userAgent", userAgent)
//                .append("resultCount", resultCount);
//        logsCollection.insertOne(logEntry);
//
//        // Write the response back to the client
//        response.setContentType("application/json");
//        response.setCharacterEncoding("UTF-8");
//        response.getWriter().write(responseBody);
//    }
//
//    private void handleDetails(HttpServletRequest request, HttpServletResponse response)
//            throws IOException, InterruptedException {
//        String animeId = request.getParameter("id");
//        if (animeId == null || animeId.trim().isEmpty()) {
//            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Parameter 'id' is required");
//            return;
//        }
//
//        String url = JIKAN_API_BASE + "/anime/" + animeId;
//        String responseBody = sendApiRequest(url);
//
//        response.setContentType("application/json");
//        response.setCharacterEncoding("UTF-8");
//        response.getWriter().write(responseBody);
//    }
//
//    private void handleDashboard(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        // Get top searches
//        List<Document> topSearches = logsCollection.aggregate(Arrays.asList(
//                Aggregates.group("$searchTerm", Accumulators.sum("count", 1)),
//                Aggregates.sort(descending("count")),
//                Aggregates.limit(5)
//        )).into(new ArrayList<>());
//
//        // Get average response time
//        Document avgResponse = logsCollection.aggregate(Arrays.asList(
//                Aggregates.group(null, Accumulators.avg("avgTime", "$responseTime"))
//        )).first();
//
//        // Get today's request count
//        Calendar cal = Calendar.getInstance();
//        cal.set(Calendar.HOUR_OF_DAY, 0);
//        cal.set(Calendar.MINUTE, 0);
//        cal.set(Calendar.SECOND, 0);
//        long todayCount = logsCollection.countDocuments(
//                gte("timestamp", cal.getTime())
//        );
//
//        // Get recent logs
//        List<Document> recentLogs = logsCollection.find()
//                .sort(descending("timestamp"))
//                .limit(10)
//                .into(new ArrayList<>());
//
//        // Set attributes for JSP
//        request.setAttribute("topSearches", topSearches);
//        request.setAttribute("avgResponseTime",
//                avgResponse != null ? String.format("%.2f", avgResponse.getDouble("avgTime")) : "0.00");
//        request.setAttribute("todayRequests", todayCount);
//        request.setAttribute("recentLogs", recentLogs);
//
//        // Forward to dashboard JSP
//        request.getRequestDispatcher("/WEB-INF/dashboard.jsp").forward(request, response);
//    }
//
//    private void handleTopAnime(HttpServletRequest request, HttpServletResponse response)
//            throws IOException, InterruptedException {
//        String url = JIKAN_API_BASE + "/top/anime?rating=g&rating=pg&rating=pg13&rating=r17";
//        String responseBody = sendApiRequest(url);
//
//        response.setContentType("application/json");
//        response.setCharacterEncoding("UTF-8");
//        response.getWriter().write(responseBody);
//    }
//
//    private void handleTopAiring(HttpServletRequest request, HttpServletResponse response)
//            throws IOException, InterruptedException {
//        String url = JIKAN_API_BASE + "/top/anime?filter=airing&rating=pg13&rating=r17";
//        String responseBody = sendApiRequest(url);
//
//        response.setContentType("application/json");
//        response.setCharacterEncoding("UTF-8");
//        response.getWriter().write(responseBody);
//    }
//
//    private void handleSeasonalAnime(HttpServletRequest request, HttpServletResponse response)
//            throws IOException, InterruptedException {
//        String url = JIKAN_API_BASE + "/seasons/now?rating=g&rating=pg&rating=pg13&rating=r17";
//        String responseBody = sendApiRequest(url);
//
//        response.setContentType("application/json");
//        response.setCharacterEncoding("UTF-8");
//        response.getWriter().write(responseBody);
//    }
//
//    private String sendApiRequest(String url) throws IOException, InterruptedException {
//        HttpRequest apiRequest = HttpRequest.newBuilder()
//                .GET()
//                .uri(URI.create(url))
//                .header("Accept", "application/json")
//                .build();
//
//        HttpResponse<String> apiResponse = httpClient.send(apiRequest, HttpResponse.BodyHandlers.ofString());
//        return apiResponse.body();
//    }
//
//    @Override
//    public void destroy() {
//        if (mongoClient != null) {
//            mongoClient.close();
//        }
//    }
//}
