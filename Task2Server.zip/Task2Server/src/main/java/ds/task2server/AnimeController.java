package ds.task2server;

import ds.task2server.AnimeModel;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Author: Pat Serrano (pserrano)
 * Last Modified: Nov 22, 2024
 *
 * The AnimeController servlet acts as the controller in the MVC pattern.
 * It handles HTTP requests, interacts with the AnimeModel, and directs responses
 * to the appropriate views.
 */
@WebServlet("/anime/*")
public class AnimeController extends HttpServlet {
    private AnimeModel animeModel;

    @Override
    public void init() throws ServletException {
        String connectionString = "mongodb+srv://pserrano:Dismproj1234@dism.zanxk.mongodb.net/?retryWrites=true&w=majority&appName=DISM";
        try {
            animeModel = new AnimeModel(connectionString);
        } catch (Exception e) {
            throw new ServletException("Failed to initialize AnimeModel", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String pathInfo = request.getPathInfo();
        if (pathInfo == null) pathInfo = "/";

        try {
            switch (pathInfo) {
                case "/search":
                    handleSearch(request, response);
                    break;
                case "/details":
                    handleDetails(request, response);
                    break;
                case "/dashboard":
                    handleDashboard(request, response);
                    break;
                case "/top":
                    handleTopAnime(request, response);
                    break;
                case "/top-airing":
                    handleTopAiring(request, response);
                    break;
                case "/seasonal":
                    handleSeasonalAnime(request, response);
                    break;
                default:
                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
                    break;
            }
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Error processing request: " + e.getMessage());
        }
    }

    private void handleSearch(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String query = request.getParameter("q");
        if (query == null || query.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Query parameter 'q' is required");
            return;
        }

        String clientIP = request.getRemoteAddr();
        String userAgent = request.getHeader("User-Agent");

        String responseBody = animeModel.searchAnime(query, clientIP, userAgent);

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(responseBody);
    }

    private void handleDetails(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String animeId = request.getParameter("id");
        if (animeId == null || animeId.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Parameter 'id' is required");
            return;
        }

        String responseBody = animeModel.getAnimeDetails(animeId);

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(responseBody);
    }

    private void handleDashboard(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            var dashboardData = animeModel.getDashboardData();

            request.setAttribute("topSearches", dashboardData.get("topSearches"));
            double avgResponseTime = (double) dashboardData.get("avgResponseTime");
            request.setAttribute("avgResponseTime", String.format("%.2f", avgResponseTime));
            request.setAttribute("todayRequests", dashboardData.get("todayRequests"));
            request.setAttribute("recentLogs", dashboardData.get("recentLogs"));

            request.getRequestDispatcher("/WEB-INF/dashboard.jsp").forward(request, response);
        } catch (Exception e) {
            throw new ServletException("Error retrieving dashboard data", e);
        }
    }

    private void handleTopAnime(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String responseBody = animeModel.getTopAnime();

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(responseBody);
    }

    private void handleTopAiring(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String responseBody = animeModel.getTopAiringAnime();

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(responseBody);
    }

    private void handleSeasonalAnime(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String responseBody = animeModel.getSeasonalAnime();

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(responseBody);
    }

    @Override
    public void destroy() {
        if (animeModel != null) {
            animeModel.close();
        }
    }
}
